package bounce;
import java.awt.Color;

public class DynamicRectangleShape extends RectangleShape {
	private Color color;
	private boolean solid = true;
	
	public DynamicRectangleShape(int x, int y, int deltaX, int deltaY, int width, int height) {
		super(x, y, deltaX, deltaY, width, height);
		this.color = Color.red;
	}
	
	public DynamicRectangleShape(int x, int y, int deltaX, int deltaY, int width, int height, Color color) {
		super(x, y, deltaX, deltaY, width, height);
		this.color = color;
	}
	
	@Override
	public void paint(Painter painter) {
		if (solid == true) {
			painter.setColor(color);
			painter.fillRect(_x,_y,_width,_height);
		} else {
			super.paint(painter);
		}
		painter.setColor(Color.black);
	}
	
	@Override
	public void move(int width, int height) {
		int nextX = super._x + super._deltaX;
		int nextY = super._y + super._deltaY;

		if (((nextX <= 0 || nextX + super._width >= width) && (nextY <= 0 || nextY + super._height >= height)) || (nextX <= 0 || nextX + super._width >= width)) { // HITS A CORNER OR HORIZONTAL WALL
			solid = true;
		} else if (nextY <= 0 || nextY + super._height >= height) { // VERTICAL WALL
			solid = false;
		} 
		super.move(width, height);
	}
}
