package bounce;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class ImageRectangleShape extends RectangleShape {
	private Image image;

	public ImageRectangleShape(int deltaX, int deltaY, Image image) {
		super(DEFAULT_X_POS, DEFAULT_Y_POS, deltaX, deltaY);
		this.image = image;
	}

	public static Image makeImage(String imageFileName, int shapeWidth) {
		File file = new File(imageFileName);
		BufferedImage b = null;
		BufferedImage b2 = null;
		try {
			b = ImageIO.read(file);
			b2 = b;
			int width = b.getWidth();
			int height = b.getHeight();
			System.out.println(width);
			System.out.println(shapeWidth);
			if (width > shapeWidth) {
				double scaleFactor = (double) shapeWidth / width;
				int shapeHeight = (int) ((double) height * scaleFactor);
				b2 = new BufferedImage(shapeWidth, shapeHeight, BufferedImage.TYPE_INT_RGB);
				Graphics2D g = b2.createGraphics();
				g.drawImage(b, 0, 0, shapeWidth, shapeHeight, null);
				System.out.println(shapeWidth);
				System.out.println(b2.getWidth());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return b2;
	}
	
	public void paint(Painter painter) {
		super.paint(painter);
		painter.drawImage(image, _x, _y, image.getWidth(null), image.getHeight(null));
	}
}
